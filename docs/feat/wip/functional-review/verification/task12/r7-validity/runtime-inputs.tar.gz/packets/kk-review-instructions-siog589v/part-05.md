Instruction packet bootstrap: part 5/6

Before presenting, reconcile every claimed inspection or execution with successful returned tool results. Denied reads, unread source and truncated results belong under missing coverage. A supported finding does not establish that the full diff was inspected or tests ran; remove unsupported coverage claims, including copied template wording.

Record outstanding evidence or release/migration/activation prerequisites and next actions; name their durable tracking location when deferred. Preserve disagreement and uncertainty. Reviewer agreement never replaces source evidence. In isolated reporting, retain native external findings and annotations, disclose failures or zero/incomplete source coverage, and do not claim corroboration or broad safety from an underfed external result. Useful available findings remain reportable.

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7B-standard-1/plugins/kk/profiles/go/DETECTION.md
SHA256 aaaa491fef20a6e46427a13de5cbb74d42b8e5479d33d3ea5c4c0bb6c656bf99
Resolve links relative to this original source path.

# Go — detection

Declares when the `go` profile activates on a given set of files. Consumed by `klaude-plugin/skills/_shared/profile-detection.md`. Multiple profiles may activate additively on the same diff.

## Path signals

_None._ Go detection does not use path heuristics; file extension alone is authoritative (see Content signals).

## Filename signals

_None._ Go detection is extension-based, not filename-based.

## Content signals

A file activates the Go profile if its extension is `.go`. The extension match is authoritative; no byte-level content inspection is required.

## Design signals

display_name: Go
tokens:
  - Go
  - Golang
  - goroutine
  - go module
  - go.mod

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7B-standard-1/plugins/kk/profiles/python/DETECTION.md
SHA256 3117026f7aaed4a4a693e2f728414911554e869f2bf8ae61338f51f383204fa3
Resolve links relative to this original source path.

# Python — detection

Declares when the `python` profile activates on a given set of files. Consumed by `klaude-plugin/skills/_shared/profile-detection.md`. Multiple profiles may activate additively on the same diff.

## Path signals

_None._ Python detection does not use path heuristics; file extension alone is authoritative (see Content signals).

## Filename signals

_None._ Python detection is extension-based, not filename-based.

## Content signals

A file activates the Python profile if its extension is one of: `.py`, `.pyi`. The extension match is authoritative; no byte-level content inspection is required.

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7B-standard-1/plugins/kk/profiles/java/DETECTION.md
SHA256 4570d20deff3ed51fbfdae57ce1a978ba7fa0159fcf6e90931299b520caf5804
Resolve links relative to this original source path.

# Java — detection

Declares when the `java` profile activates on a given set of files. Consumed by `klaude-plugin/skills/_shared/profile-detection.md`. Multiple profiles may activate additively on the same diff.

## Path signals

_None._ Java detection does not use path heuristics; file extension alone is authoritative (see Content signals).

## Filename signals

_None._ Java detection is extension-based, not filename-based.

## Content signals

A file activates the Java profile if its extension is `.java`. The extension match is authoritative; no byte-level content inspection is required.

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7B-standard-1/plugins/kk/profiles/js_ts/DETECTION.md
SHA256 fc28aeaf58d608e56d0ce3cac16a948e26f32abd6dd7a2273d3c3ca1d91aeb73
Resolve links relative to this original source path.

# JS/TS — detection

Declares when the `js_ts` profile activates on a given set of files. Consumed by `klaude-plugin/skills/_shared/profile-detection.md`. Multiple profiles may activate additively on the same diff.

The profile covers JavaScript and TypeScript jointly: review concerns (typing, async, modules, React patterns) overlap substantially, and the ecosystem tools (npm, bundlers, Node/browser runtimes) are shared.

## Path signals

_None._ JS/TS detection does not use path heuristics; file extension alone is authoritative (see Content signals).

## Filename signals

_None._ JS/TS detection is extension-based, not filename-based.

## Content signals

A file activates the JS/TS profile if its extension is one of: `.js`, `.jsx`, `.mjs`, `.cjs`, `.ts`, `.tsx`, `.mts`, `.cts`. The extension match is authoritative; no byte-level content inspection is required.

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7B-standard-1/plugins/kk/profiles/kotlin/DETECTION.md
SHA256 6defa878b07dbd0e0e4f0ff176a8280072d9e9459aa9e578087d2bbcf20ea86c
Resolve links relative to this original source path.

# Kotlin — detection

Declares when the `kotlin` profile activates on a given set of files. Consumed by `klaude-plugin/skills/_shared/profile-detection.md`. Multiple profiles may activate additively on the same diff.

## Path signals

_None._ Kotlin detection does not use path heuristics; file extension alone is authoritative (see Content signals).

## Filename signals

_None._ Kotlin detection is extension-based, not filename-based.

## Content signals

A file activates the Kotlin profile if its extension is one of: `.kt`, `.kts`. The extension match is authoritative; no byte-level content inspection is required.

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7B-standard-1/plugins/kk/profiles/k8s/DETECTION.md
SHA256 bdfc761757e52658c870f1dbf95c05110e781ad5f6782df71af3b286f4b7c847
Resolve links relative to this original source path.

# Kubernetes — detection

Declares when the `k8s` profile activates on a given set of files. Consumed by `klaude-plugin/skills/_shared/profile-detection.md`. Detection is additive: multiple profiles may activate on the same diff (e.g., `go` + `k8s`).

Evaluation follows the shared cost-ordered procedure (path → filename → content). Authority runs filename ≈ content > path: filename or content signals activate the profile; path alone never does, it only promotes a file to a candidate.

## Path signals

Case-insensitive substring match anywhere in the file's path. Pre-filter only — a path hit alone does NOT activate the profile.

- `k8s/`
- `manifests/`
- `charts/`
- `kustomize/`
- `deploy/`
- `templates/`

## Filename signals

Authoritative: any match activates the profile. Filename matches short-circuit content inspection for the matched file.

- `Chart.yaml` (exact) → Helm chart root.
- Any filename starting with `values` (e.g., `values.yaml`, `values.yml`, `values-prod.yaml`, `values-prod-v2-final.yaml`) when the containing directory also contains `Chart.yaml` → Helm values by adjacency. The `values*` glob has no upper bound on the wildcard; the adjacency rule (sibling `Chart.yaml` in the same directory) is the binding constraint. The match is filename-plus-adjacency only — file content is not inspected, so a file named `values-backup.yaml` next to a `Chart.yaml` activates regardless of what it actually contains.
- Any file with extension `.yaml`, `.yml`, or `.tpl` inside `<dir>/templates/` where `<dir>` itself contains a `Chart.yaml` as a direct child → Helm template. The binding constraint is that the `templates/` directory must sit *directly* next to a `Chart.yaml` — i.e., at a chart root or a subchart root under `<parent>/charts/<subchart>/`. A `templates/` nested elsewhere in the tree (e.g., `docs/templates/`, `ci/templates/`) does NOT activate this rule even when a `Chart.yaml` sits at the repository root, because `docs/` and `ci/` do not themselves contain a `Chart.yaml`. This avoids the monorepo false-positive where a repo-root umbrella `Chart.yaml` would otherwise claim every `templates/` directory in the tree. It still avoids the trap where a standalone edit to `<chart-root>/templates/deployment.yaml` contains `{{ if ... }}` directives before any `apiVersion:` and would otherwise fail the content signal.
- Exact filenames `kustomization.yaml`, `kustomization.yml`, or `Kustomization` → Kustomize.

## Content signals

Authoritative for generic YAML files (`.yaml` or `.yml`) not already caught by a filename signal. Inspection is bounded to the first ~16 KB per file; large generated manifests beyond that bound are not inspected.

- Split the file on `---` document separators. For each `---`-separated document block, check for a top-level `apiVersion:` AND a top-level `kind:` — parsed as YAML mapping keys at zero indent, not as substrings inside block scalars (`|`, `>`) or comments. A block satisfying both is a Kubernetes manifest document.
- One matching document activates the profile for that file. The first document need not match — a file whose second or later document is the only K8s document still activates.
- A `.yaml` / `.yml` file with no matching document in any block → not Kubernetes. (It may still match another profile; generic YAML belongs to no profile by default.)

---

## Multi-profile behavior

The Kubernetes profile is **additive**. It coexists with programming-language profiles or any other IaC profile on the same diff. When Go source files sit alongside Kubernetes manifests, both `go` and `k8s` activate; downstream skills consult both profiles' content and emit findings grouped by `(profile, checklist)`.

## Design signals

display_name: Kubernetes
tokens:
  - Kubernetes
  - K8s
  - Helm chart
  - kubectl
  - kustomize
  - manifest.yaml
  - Deployment resource
  - StatefulSet
  - DaemonSet
  - CronJob

## Dockerfile non-trigger

A Dockerfile on its own — even under a `deploy/` or `k8s/` directory — does NOT activate the `k8s` profile. Dockerfiles match no filename signal here (they are not `Chart.yaml` / `values*.yaml` / `kustomization.yaml`) and no content signal (they do not contain `apiVersion:` + `kind:`). When a Dockerfile appears in the same diff as Kubernetes manifests, `k8s` activates on the manifests' signals; the Dockerfile itself is not reviewed by this profile. A future container profile may own Dockerfiles independently.

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7B-standard-1/plugins/kk/profiles/k8s-operator/DETECTION.md
SHA256 4d3e0f1d5d5a847c18577619f7569fffd8c61ed29a0dde0c4a2955504246acbd
Resolve links relative to this original source path.

# Kubernetes Operator — detection

Declares when the `k8s-operator` profile activates on a given set of files. Consumed by `klaude-plugin/skills/_shared/profile-detection.md`. Detection is additive: an operator project typically activates both `k8s-operator` (for controller code) and `k8s` (for the manifests it generates/deploys).

Evaluation follows the shared cost-ordered procedure (path → filename → content). Authority runs filename ≈ content > path: filename or content signals activate the profile; path alone never does, it only promotes a file to a candidate.

## Path signals

Case-insensitive substring match anywhere in the file's path. Pre-filter only — a path hit alone does NOT activate the profile.

- `internal/controller/`
- `api/`
- `controllers/`

## Filename signals

Authoritative: any match activates the profile. Filename matches short-circuit content inspection for the matched file.

- `PROJECT` (exact) → kubebuilder project marker. This file is generated by `kubebuilder init` and contains the project's domain, layout, and plugin metadata. Its mere presence signals an operator project.
- Any file under `config/crd/` → CRD kustomize bases generated by `controller-gen`.
- Any file under `config/webhook/` → admission/conversion webhook kustomize configuration.

## Content signals

Authoritative for files not already caught by a filename signal. Inspection is bounded to the first ~16 KB per file.


END PACKET PART 5/6
