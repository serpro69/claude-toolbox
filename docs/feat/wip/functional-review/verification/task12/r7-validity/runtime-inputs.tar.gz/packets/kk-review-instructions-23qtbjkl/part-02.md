Instruction packet checklists: part 2/2

- **Missing indexes**: Queries on unindexed columns
- **Over-fetching**: SELECT * when only few columns needed
- **No pagination**: Loading entire dataset into memory

### Caching Issues

- **Missing cache for expensive operations**: Repeated API calls, DB queries, computations
- **Cache without TTL**: Stale data served indefinitely
- **Cache without invalidation strategy**: Data updated but cache not cleared
- **Cache key collisions**: Insufficient key uniqueness
- **Caching user-specific data globally**: Security/privacy issue

### Memory

- **Unbounded collections**: Lists/dicts that grow without limit
- **Large object retention**: Holding references preventing GC, circular references
- **String concatenation in loops**: Use `"".join(parts)` instead
- **Loading large files entirely**: Use streaming/iterator patterns instead
- **Mutable default arguments**: `def foo(items=[])` — default list is shared across all calls, mutating it causes cross-call contamination
- **Generator exhaustion**: Iterating a generator/iterator twice silently produces no results on the second pass
- **Missing context managers**: Not using `with` for files, DB connections, locks — resources leak on exceptions
- **Late binding closures**: Lambdas/closures in loops capture the variable by reference, not by value — all closures see the final loop value
- **`__del__` unreliability**: `__del__` is not guaranteed to run — never rely on it for cleanup; use context managers or `atexit`

### Questions to Ask
- "What's the time complexity of this operation?"
- "How does this behave with 10x/100x data?"
- "Is this result cacheable? Should it be?"
- "Can this be batched instead of one-by-one?"

---

## Boundary Conditions

### None Handling

- **Missing None checks**: Accessing attributes on potentially `None` objects (causes `AttributeError`)
- **Truthiness confusion**: `if value:` when `0`, `""`, `[]`, `{}` are valid values
- **Excessive None checks**: Deep chains of `if x is not None and x.y is not None` hiding structural issues
- **`is` vs `==` confusion**: Using `is` to compare values instead of `==` — works unreliably due to interning (e.g., `x is "hello"` may pass for small strings but fail for others)
- **None vs missing inconsistency**: Mixed usage of `None` and sentinel values without clear convention

### Empty Collections

- **Empty list not handled**: Code assumes list has items
- **Empty dict edge case**: Iteration or key access on empty dict
- **First/last element access**: `items[0]` or `items[-1]` without length check

### Numeric Boundaries

- **Division by zero**: Missing check before division (raises `ZeroDivisionError`)
- **Integer overflow**: Python handles big ints natively, but watch for C-extension or struct boundaries
- **Floating point comparison**: Using `==` instead of `math.isclose`
- **Negative values**: Index or count that shouldn't be negative
- **Off-by-one errors**: Loop bounds, slicing, pagination

### String Boundaries

- **Empty string**: Not handled as edge case
- **Whitespace-only string**: Passes truthiness check but is effectively empty
- **Very long strings**: No length limits causing memory/display issues
- **Unicode edge cases**: Emoji, RTL text, combining characters

### Common Patterns to Flag

```python
# Dangerous: no None check (AttributeError if user or profile is None)
name = user.profile.name

# Dangerous: list access without check (IndexError if items is empty)
first = items[0]

# Dangerous: division without check (ZeroDivisionError if count is 0)
avg = total / count

# Dangerous: truthiness check excludes valid values
if value:  ...   # fails for 0, "", [], {}, False
```

### Questions to Ask
- "What if this is None?"
- "What if this collection is empty?"
- "What's the valid range for this number?"
- "What happens at the boundaries (0, -1, sys.maxsize)?"

END SOURCE

BEGIN SOURCE /private/tmp/fr-r7-validity-20261014/claude-candidate-R7M-standard-2/plugins/kk/profiles/python/review-code/removal-plan.md
SHA256 e88a86bc30334a75438222f93c5163ba9da3d4c5fc275ef334ba2b546a804ffa
Resolve links relative to this original source path.

# Removal and Iteration Plan Template

## Priority Levels

- [ ] **P0**: Immediate removal needed (security risk, significant cost, blocking other work)
- [ ] **P1**: Remove in current sprint
- [ ] **P2**: Backlog / next iteration

---

## Safe to Remove Now

### Item: [Name/Description]

| Field | Details |
|-------|---------|
| **Location** | `path/to/file.py:line` |
| **Rationale** | Why this should be removed |
| **Evidence** | Unused (no references), dead feature flag, deprecated API |
| **Impact** | None / Low - no active consumers |
| **Deletion steps** | 1. Remove code 2. Remove tests 3. Remove config |
| **Verification** | Run tests, check no runtime errors, monitor logs |

---

## Defer Removal (Plan Required)

### Item: [Name/Description]

| Field | Details |
|-------|---------|
| **Location** | `path/to/file.py:line` |
| **Why defer** | Active consumers, needs migration, stakeholder sign-off |
| **Preconditions** | Feature flag off for 2 weeks, telemetry shows 0 usage |
| **Breaking changes** | List any API/contract changes |
| **Migration plan** | Steps for consumers to migrate |
| **Timeline** | Target date or sprint |
| **Owner** | Person/team responsible |
| **Validation** | Metrics to confirm safe removal (error rates, usage counts) |
| **Rollback plan** | How to restore if issues found |

---

## Checklist Before Removal

- [ ] Searched codebase for all references (`rg`, `grep`)
- [ ] Checked for dynamic/reflection-based usage (`getattr`, `importlib`)
- [ ] Verified no external consumers (APIs, SDKs, docs)
- [ ] Feature flag telemetry reviewed (if applicable)
- [ ] Tests updated/removed
- [ ] Documentation updated
- [ ] Team notified (if shared code)

END SOURCE

END PACKET PART 2/2
