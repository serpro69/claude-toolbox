# Change context (factual record, parent-prepared)

## Intent and authority
- README.md (repo root): client and provider ship independently. Every merged client
  increment must support the released provider at Git tag `eval-release`, including
  ordinary settings saves while enhanced_settings is false. `provider/settings.py` at
  that tag is the supported provider source. A successful settings save means values
  were applied and the caller sees success. The candidate provider is not deployed and
  a pending provider task cannot change the supported baseline. (explicit)
- docs/feat/wip/enhanced-settings/design.md: ordinary saves must continue to work with
  the supported provider at eval-release; enhanced UI disabled by default; add an
  application receipt to the protocol in client and provider increments while
  preserving independently releasable main. (explicit)
- docs/feat/wip/enhanced-settings/implementation.md: Task 1 = client-side receipt
  handling + unit test; Task 2 = provider receipts in separate provider repository.
  Review only the client increment; shared delivery contract still applies. (explicit)

## Change boundary
- Selector: staged changes (`git diff --cached`); no unstaged changes exist.
- Review base: HEAD ac09e55463b2d33bba4cdf6a759d759e3d80c024. Candidate: index.
  Worktree files equal index blobs (status shows staged-only modifications).
- Changed files: client.py (index blob 910e877), tests/test_client.py (index blob f1dfc4f).
- Pending: Task 2 provider receipts.

## Existing behavior
- Entry point: client.save_settings(send, workspace_id, values, enhanced_settings=False).
- No other in-repo callers of save_settings besides tests/test_client.py (grep).
- Released provider (eval-release provider/settings.py, see historical bundle) stores
  request["settings"] and returns {"ok": True}; it does not read `require_receipt`
  and returns no `applied` key.

## Delivery constraints
- Independently releasable main; client must support eval-release provider for
  ordinary saves with enhanced_settings false. No live environment.

## Baselines
- Review base: HEAD ac09e55. Compatibility baseline: tag eval-release
  (22140737b2bc5792b535f3f8ce16f7fa162101db), source-level only.

## Verification results
- No tests were executed by the parent for this review package. README test command:
  `python3 -B -m unittest discover -s tests`. No author-supplied test results.

## Rejected approaches
- None recorded.
