# Historical evidence provenance

| Field | Value |
| --- | --- |
| Repository | local checkout /tmp/fr-r7-conclusions-20261013/claude-candidate-R3-isolated-2 |
| Ref | tag `eval-release` |
| Full revision | 22140737b2bc5792b535f3f8ce16f7fa162101db |
| Original path | provider/settings.py |
| Git blob | a6aeedb05fcf8c2c11b68cf16b560bf5f245eada |
| Line span | 1-3 (complete file) |
| Omitted/redacted | none |
| Snapshot path | /tmp/kk-review-code-GQVKG1/historical/eval-release/provider/settings.py |

Obtained via `git show eval-release:provider/settings.py`. This is a source-level
release snapshot named by README.md as the supported provider source; it is not
verified deployment state (README: no live environment is available or required).
