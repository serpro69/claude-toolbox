Instruction packet checklists: part 1/2


BEGIN SOURCE /tmp/fr-r7-conclusions-20261013/claude-candidate-R5-standard-2/plugins/kk/profiles/python/review-code/security-checklist.md
SHA256 d88e5779ba297ee7008dc0450ef62b5bacf50cdeb35a18b9a6f9afe64d8e31bc
Resolve links relative to this original source path.

# Security and Reliability Checklist

## Contents
- Input/Output Safety (XSS, injection, SSRF, path traversal, unsafe deserialization)
- AuthN/AuthZ
- JWT & Token Security
- Secrets and PII
- Supply Chain & Dependencies
- CORS & Headers
- Runtime Risks (unbounded ops, GIL contention, resource exhaustion)
- Cryptography
- Race Conditions (shared state, TOCTOU, database concurrency, distributed)
- Data Integrity

## Input/Output Safety

- **XSS**: Unsafe HTML injection, Jinja2 `|safe` filter or `Markup()` bypassing auto-escaping, raw string interpolation in HTML responses
- **Injection**: SQL injection via f-strings or `%` formatting instead of parameterized queries; command injection via `os.system`, `subprocess.run(shell=True)` with user input
- **SSRF**: User-controlled URLs reaching internal services without allowlist validation
- **Path traversal**: User input in file paths without sanitization (`../` attacks), `os.path.join` with absolute user input bypassing base directory
- **Unsafe deserialization**: Using `pickle.loads`, `yaml.load` (without `SafeLoader`), or `eval`/`exec` on untrusted input
- **Code injection via imports**: User input reaching `__import__`, `importlib.import_module`, or dynamic module loading

## AuthN/AuthZ

- Missing tenant or ownership checks for read/write operations
- New endpoints without auth guards or RBAC enforcement
- Trusting client-provided roles/flags/IDs
- Broken access control (IDOR - Insecure Direct Object Reference)
- Session fixation or weak session management

## JWT & Token Security

- Algorithm confusion attacks (accepting `none` or `HS256` when expecting `RS256`)
- Weak or hardcoded secrets
- Missing expiration (`exp`) or not validating it
- Sensitive data in JWT payload (tokens are base64, not encrypted)
- Not validating `iss` (issuer) or `aud` (audience)

## Secrets and PII

- API keys, tokens, or credentials in code/config/logs
- Secrets in git history or environment variables exposed to client
- Excessive logging of PII or sensitive payloads
- Missing data masking in error messages

## Supply Chain & Dependencies

- Unpinned dependencies allowing malicious updates (missing version pins in `requirements.txt`/`pyproject.toml`)
- Dependency confusion (private package name collision on PyPI)
- Importing from untrusted sources without integrity checks
- Outdated dependencies with known CVEs

## CORS & Headers

- Overly permissive CORS (`Access-Control-Allow-Origin: *` with credentials)
- Missing security headers (CSP, X-Frame-Options, X-Content-Type-Options)
- Exposed internal headers or stack traces

## Runtime Risks

- Unbounded loops, recursive calls, or large in-memory buffers
- Missing timeouts, retries, or rate limiting on external calls
- Blocking operations on the event loop (sync I/O in `async` context)
- Resource exhaustion (file handles, connections, memory)
- **`assert` stripped in optimized mode**: `python -O` removes all `assert` statements — never use `assert` for security/input validation
- ReDoS (Regular Expression Denial of Service)

## Cryptography

- Weak algorithms (MD5, SHA1 for security purposes)
- Hardcoded IVs or salts
- Using encryption without authentication (ECB mode, no HMAC)
- Insufficient key length
- Using `==` for secret/token comparison instead of `hmac.compare_digest` (leaks timing information)

## Race Conditions

Race conditions are subtle bugs that cause intermittent failures and security vulnerabilities. Pay special attention to:

### Shared State Access
- Multiple threads accessing shared variables without locks (GIL does not protect multi-step operations)
- Global state or module-level mutables modified concurrently
- Lazy initialization without proper locking
- Non-thread-safe collections used in concurrent context

### Check-Then-Act (TOCTOU)
- `if (exists) then use` patterns without atomic operations
- `if (authorized) then perform` where authorization can change
- File existence check followed by file operation
- Balance check followed by deduction (financial operations)
- Inventory check followed by order placement
- `tempfile.mktemp()` is deprecated (TOCTOU race) — use `tempfile.mkstemp()` or `NamedTemporaryFile`

### Database Concurrency
- Missing optimistic locking (`version` column, `updated_at` checks)
- Missing pessimistic locking (`SELECT FOR UPDATE`)
- Read-modify-write without transaction isolation
- Counter increments without atomic operations (`UPDATE SET count = count + 1`)
- Unique constraint violations in concurrent inserts

### Distributed Systems
- Missing distributed locks for shared resources
- Leader election race conditions
- Cache invalidation races (stale reads after writes)
- Event ordering dependencies without proper sequencing
- Split-brain scenarios in cluster operations

### Common Patterns to Flag
```python
# Dangerous patterns:

# TOCTOU
if not os.path.exists(path):
    open(path, "w").write(data)

# Read-modify-write
value = cache.get(key)
value += 1
cache.set(key, value)

# Check-then-act
if user.balance >= amount:
    user.balance -= amount
    user.save()
```

### Questions to Ask
- "What happens if two requests hit this code simultaneously?"
- "Is this operation atomic or can it be interrupted?"
- "What shared state does this code access?"
- "How does this behave under high concurrency?"

## Data Integrity

- Missing transactions, partial writes, or inconsistent state updates
- Weak validation before persistence (implicit type conversion issues)
- Missing idempotency for retryable operations
- Lost updates due to concurrent modifications

END SOURCE

BEGIN SOURCE /tmp/fr-r7-conclusions-20261013/claude-candidate-R5-standard-2/plugins/kk/profiles/python/review-code/solid-checklist.md
SHA256 5acb4b669369ade34f91f25156866e7f3d0048613dabe362bb8858d90bb254f3
Resolve links relative to this original source path.

# SOLID Smell Prompts

## SRP (Single Responsibility)

- File owns unrelated concerns (e.g., HTTP + DB + domain rules in one file)
- Large class/module with low cohesion or multiple reasons to change
- Functions that orchestrate many unrelated steps
- God objects that know too much about the system
- Circular imports between modules (signals tangled responsibilities — causes `ImportError`/`AttributeError` at runtime)
- **Ask**: "What is the single reason this module would change?"

## OCP (Open/Closed)

- Adding a new behavior requires editing many `if/elif` chains (or `match/case` blocks)
- Feature growth requires modifying core logic rather than extending
- No plugin/strategy/hook points for variation
- **Ask**: "Can I add a new variant without touching existing code?"

## LSP (Liskov Substitution)

- Subclass checks for concrete type via `isinstance` or raises for base method
- Overridden methods weaken preconditions or strengthen postconditions
- Subclass ignores or no-ops parent behavior
- **Ask**: "Can I substitute any subclass without the caller knowing?"

## ISP (Interface Segregation)

- ABCs/Protocols with many methods, most unused by implementers
- Callers depend on broad interfaces for narrow needs
- `NotImplementedError` stubs in subclasses
- **Ask**: "Do all implementers use all methods?"

## DIP (Dependency Inversion)

- High-level logic depends on concrete IO, storage, or network types
- Hard-coded implementations instead of abstractions or injection
- Import chains that couple business logic to infrastructure
- **Ask**: "Can I swap the implementation without changing business logic?"

---

## Common Code Smells (Beyond SOLID)

| Smell | Signs |
|-------|-------|
| **Long method** | Function > 30 lines, multiple levels of nesting |
| **Feature envy** | Method uses more data from another class than its own |
| **Data clumps** | Same group of parameters passed together repeatedly |
| **Primitive obsession** | Using strings/numbers instead of domain types |
| **Shotgun surgery** | One change requires edits across many files |
| **Divergent change** | One file changes for many unrelated reasons |
| **Dead code** | Unreachable or never-called code |
| **Speculative generality** | Abstractions for hypothetical future needs |
| **Magic numbers/strings** | Hardcoded values without named constants |
| **Expensive `@property`** | Property getter performs I/O, DB queries, or heavy computation — callers expect attribute access to be cheap |

---

## Refactor Heuristics

1. **Split by responsibility, not by size** - A small file can still violate SRP
2. **Introduce abstraction only when needed** - Wait for the second use case
3. **Keep refactors incremental** - Isolate behavior before moving
4. **Preserve behavior first** - Add tests before restructuring
5. **Name things by intent** - If naming is hard, the abstraction might be wrong
6. **Prefer composition over inheritance** - Multiple inheritance creates MRO complexity and tight coupling
7. **Make illegal states unrepresentable** - Use types to enforce invariants

END SOURCE

BEGIN SOURCE /tmp/fr-r7-conclusions-20261013/claude-candidate-R5-standard-2/plugins/kk/profiles/python/review-code/code-quality-checklist.md
SHA256 727d2bd6eb1c5fa1216b9b81db3e7d18da08c580dc42dee2d68ae94f08f5748e
Resolve links relative to this original source path.

# Code Quality Checklist

## Contents
- Error Handling (anti-patterns, best practices, questions)
- Performance & Caching (CPU, database/IO, caching, memory)
- Boundary Conditions (None handling, empty collections, numeric, string)

## Error Handling

### Anti-patterns to Flag

- **Swallowed exceptions**: Empty `except` blocks or catch with only logging. Example:
  ```python
  try: ...
  except Exception: pass              # Silent failure
  try: ...
  except Exception as e: print(e)     # Log and forget, no re-raise
  ```
- **Overly broad except**: Catching bare `Exception` or `BaseException` instead of specific types
- **Error information leakage**: Stack traces or internal details exposed to users
- **Missing error handling**: No try-except around fallible operations (I/O, network, parsing)
- **Async error handling**: Unhandled exceptions in `asyncio` tasks, missing `try/except` in coroutines, fire-and-forget tasks without error callbacks

### Best Practices to Check

- [ ] Errors are caught at appropriate boundaries
- [ ] Error messages are user-friendly (no internal details exposed)
- [ ] Errors are logged with sufficient context for debugging
- [ ] Async task exceptions are retrieved or handled (not silently dropped)
- [ ] Fallback behavior is defined for recoverable errors
- [ ] Critical errors trigger alerts/monitoring

### Questions to Ask
- "What happens when this operation fails?"
- "Will the caller know something went wrong?"
- "Is there enough context to debug this error?"

---

## Performance & Caching

### CPU-Intensive Operations

- **Expensive operations in hot paths**: `re.compile` in loops, JSON parsing in hot paths, crypto in loops
- **Blocking the event loop**: Sync I/O or heavy computation in `async` functions without `run_in_executor`
- **Unnecessary recomputation**: Same calculation done multiple times
- **Missing caching**: Pure functions called repeatedly with same inputs, no `@functools.lru_cache` or `@functools.cache`
- **GIL limitation for CPU-bound work**: `threading` does not parallelize CPU-bound tasks due to the GIL — use `multiprocessing` or `concurrent.futures.ProcessPoolExecutor`

### Database & I/O

- **N+1 queries**: Loop that makes a query per item instead of batch
  ```python
  # Bad: N+1
  for id in ids:
      user = db.execute("SELECT * FROM users WHERE id = %s", (id,)).fetchone()

  # Good: Batch
  users = db.execute("SELECT * FROM users WHERE id IN %s", (tuple(ids),)).fetchall()
  ```
- **Missing indexes**: Queries on unindexed columns

END PACKET PART 1/2
