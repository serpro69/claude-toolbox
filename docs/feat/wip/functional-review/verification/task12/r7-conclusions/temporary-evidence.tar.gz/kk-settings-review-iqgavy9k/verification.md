Parent-executed verification on frozen candidate index snapshot, Python 3.10.12:
- python3 -B -m unittest discover -s tests -v: 4 tests passed (empty name, normal save, preserve internal space, trim surrounding spaces).
- Inline recording-transport check through client.save: Ada unchanged; surrounding spaces trimmed; internal space preserved; empty string stays empty; whitespace-only becomes empty; tab/newline and nonbreaking-space boundaries trimmed. All 7 assertions of PUT path/body and return propagation passed.
These are local client checks using a recording/mock transport; they do not verify a live provider or accepted product semantics for whitespace-only/non-string inputs. No Python 3.9 interpreter run. No source edits.
