Instruction packet profiles: part 1/1


BEGIN SOURCE /tmp/fr-r7-conclusions-20261013/claude-candidate-R5-isolated-2/plugins/kk/profiles/python/review-code/index.md
SHA256 eeab4273a7d9899991fa4338a3620e37256cbb05d099c003466810535d6a2451
Resolve links relative to this original source path.

# Python — review checklists

Consumed by the `/kk:review-code` skill. When the `python` profile is active, every checklist in **Always load** is applied to the diff. There are no conditional entries for this profile.

## Always load

- [security-checklist.md](security-checklist.md) — Python-specific security smells: input validation, deserialization, subprocess/shell injection, crypto misuse, secret handling.
- [solid-checklist.md](solid-checklist.md) — SOLID design-principle smells expressed in Python: module cohesion, protocol segregation, dependency inversion, duck-typing boundaries.
- [code-quality-checklist.md](code-quality-checklist.md) — idiomatic Python quality signals: typing, mutability, context managers, exception hygiene, maintainability.
- [removal-plan.md](removal-plan.md) — staged-removal template for Python code being retired (modules, packages, public APIs).

END SOURCE

END PACKET PART 1/1
