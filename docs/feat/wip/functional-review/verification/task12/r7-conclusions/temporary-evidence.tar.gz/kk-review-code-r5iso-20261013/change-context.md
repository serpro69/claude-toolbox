# Change context — export-preview Task 1 (staged)

## Intent and authority (explicit)
- README.md:5-10 — existing GET /settings response and routing behavior remain the acceptance
  contract; preview activation belongs to a later task; this increment must remain independently
  compatible while that task is pending; build setting is fixed at False in source, not supplied by
  request/env/external config. No deployment inventory exists in this repo.
- tasks.md — Task 1 (in-progress, the reviewed task): preserve existing routes with preview disabled
  in the checked-in build; add the preview module and guarded route. Task 2 (pending): implement
  render_preview and enabled-path tests before changing the build setting.

## Change boundary
- Selector: `git diff --cached` (no unstaged changes). Diff: /tmp/kk-review-code-r5iso-20261013/staged.patch
- Review base: HEAD f1a16b5c97799818739131e41ea37056edf057ac. Candidate: index; `git diff` (worktree vs
  index) is empty for tracked files, so worktree files equal the candidate.
- Changed: preview.py (added), routes.py (modified). Deliberately pending: render_preview body and
  enabled-path tests (Task 2).

## Existing behavior / consumers
- routes.get(path): "/settings" -> (200, current_settings()); anything else -> (404, None).
  Base routes.py is fully visible in the diff hunk (lines 1-7).
- Unchanged files at base: config.py (EXPORT_PREVIEW_ENABLED = False), settings.py, tests/test_routes.py
  (includes test_preview_route expecting get("/export-preview") == (404, None)).

## Delivery constraints
- Independently compatible increment on the checked-in build (flag False). Python 3.9+, stdlib only.

## Baselines
- Only the review base is available; no released/deployed baseline exists in this repo (README:10).

## Verification results
- Tests NOT executed: the parent's shell execution of `python3 -B -m unittest discover -s tests` was
  denied in this session. Any test conclusions are source-only.

## Rejected approaches
- None recorded.
