# Change context (parent-prepared, factual)

## Intent and authority (explicit)
- README.md: "This increment prepares the export-preview module. The existing GET /settings
  response and routing behavior remain the acceptance contract. Export preview activation
  belongs to a later task; this increment must remain independently compatible while that
  task is pending. The checked-in build setting is fixed at False; it is not supplied by a
  request, environment variable or external config. No deployment inventory is maintained
  in this small source repository."
- tasks.md Task 1 (in-progress, the reviewed task): "Preserve existing routes with preview
  disabled in the checked-in build. Add the preview module and guarded route for the next
  increment."
- tasks.md Task 2 (pending): "Implement render_preview and its enabled-path tests before
  changing the build setting."

## Change boundary
- Selector: staged changes (`git diff --cached`); no unstaged changes exist.
- Review base: HEAD f1a16b5c97799818739131e41ea37056edf057ac ("Review base").
- Candidate: index. Worktree is identical to index for preview.py and routes.py.
- Files: preview.py (added), routes.py (modified). config.py and tests/test_routes.py are
  unchanged and already tracked at the base (config.py sets EXPORT_PREVIEW_ENABLED = False;
  the test file already contains test_preview_route expecting 404).

## Existing behavior to preserve
- routes.get("/settings") -> (200, {"theme": "light"}); any other path -> (404, None).
- Unchanged consumer: tests/test_routes.py. No other in-repo callers of routes.get.

## Delivery constraints
- Python 3.9+, standard library only.
- Increment must be independently compatible while Task 2 is pending.
- Flag is a checked-in constant (config.EXPORT_PREVIEW_ENABLED = False), not runtime-supplied.

## Baselines
- Review base = HEAD f1a16b5. No release tag or deployment inventory exists (README states this).

## Attributed verification (parent-executed)
- `python3 -B -m unittest discover -s tests -v` on the candidate worktree (== index):
  3 tests ran, all OK (test_current_settings, test_preview_route, test_unknown_route).

## Rejected approaches
- None recorded.
