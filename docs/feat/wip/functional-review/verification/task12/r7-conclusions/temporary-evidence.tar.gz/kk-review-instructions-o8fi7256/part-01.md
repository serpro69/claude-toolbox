Instruction packet bootstrap: part 1/6


BEGIN SOURCE /tmp/fr-r7-conclusions-20261013/claude-candidate-R7-standard-2/plugins/kk/skills/review-code/packet-preparation.md
SHA256 39bfec8332a4bb85ed2ba156fbf957e231d544dfc15afc46974c7ea8c23716c8
Resolve links relative to this original source path.

# Instruction preparation

Preparation has one outcome: all applicable instruction bytes have returned
before subject investigation. The helper packages existing files and checks
membership; it neither detects profiles nor grants permission to investigate.
Read-only isolated agents continue to use the direct source paths supplied by
their parent.

1. Execute the helper path supplied by SKILL.md with argument `bootstrap`.
   Read **every** returned part, in order, through its `END PACKET PART` marker.
   Request the remaining lines if a Read is truncated. These parts contain the
   full process, shared protocols, common method and every Known-profile
   detection file. Source headers give original paths for relative links.
2. Select the Git diff from filenames/metadata under the loaded process. Task
   documents and requirements are investigated only after checklist loading;
   their discovery does not open the preparation gate. Apply the
   loaded detection rules, preserving each match/non-match/ENOENT outcome.
   For active profiles, run `profiles --profile NAME` (repeat `--profile` as
   needed), then Read all returned parts to load their indexes. Resolve their
   conditionals using only the allowed bounded predicate inspection.
3. Run `checklists` with each active `--profile NAME`, a `--load
   NAME/checklist.md` for every selected entry, and a `--skip
   'NAME/checklist.md=concrete unmatched predicate'` for each unselected
   conditional. Select undecidable conditionals conservatively. The helper
   rejects incomplete index coverage, unknown entries and skipped always-load
   files. It does not verify the truth of your predicate decisions.
4. Read every checklist-packet part fully. Emit one compact preparation
   checkpoint: selected diff, detection outcomes, selected checklist sources,
   and completed packet parts. Only completed returned text counts. Then enter
   the process's investigation phase.

For no active profiles, record that result and no selected checklists; the
common instructions still apply. Packet creation and hashes establish packaging,
not reading or behavioral compliance. Use tool results to establish ordering.
Keep packet files available through the review/evidence capture; they contain
no reviewed source and live in newly allocated temporary directories.

**Direct-read fallback:** if Python/helper execution is unavailable or the
helper cannot package an instruction/index faithfully, retain that limitation and read the
process and its shared/common instructions, every Known-profile detection file,
active indexes and every selected checklist directly. Use the same scope,
predicate and completion rules. A valid complete packet Read supplies the
original source contents for those reads; do not reread identical files merely
because they arrived together. Missing required instructions still block
investigation, with only the shared detection procedure's defined fallbacks.

END SOURCE

BEGIN SOURCE /tmp/fr-r7-conclusions-20261013/claude-candidate-R7-standard-2/plugins/kk/skills/review-code/review-process.md
SHA256 341a178c8974852e088f20f3fbc468d454558b60f529afc586ad088e6a4d49dc
Resolve links relative to this original source path.

### Workflow

**Mandatory ordering — methodology before evidence.** Follow [SKILL.md](SKILL.md)'s standard workflow strictly in sequence. Load all applicable instructions before investigation or action. The bounded routing exception below selects instructions only; it permits no behavioral analysis, findings, full-diff investigation, edits or tests.

Copy and complete this checklist:

```
Code Review Progress:
- [ ] Step 1: Load basic instructions
- [ ] Step 2: Select the diff from filenames/metadata
- [ ] Step 3: Detect profiles and route all checklists
- [ ] Step 4: Read every resolved checklist
- [ ] Step 5: Investigate behavior and compatibility
- [ ] Step 6: Apply profile and general checklists
- [ ] Step 7: Self-check and confidence assessment
- [ ] Step 8: Index findings
- [ ] Step 9: Present findings, coverage and verdict
- [ ] Step 10: Close the review or handle required next steps
- [ ] Step 11: Verify outputs
```

### 1) Load basic instructions

Read this entire process and [shared-capy-knowledge-protocol.md](shared-capy-knowledge-protocol.md), [shared-profile-detection.md](shared-profile-detection.md), [shared-review-scope-protocol.md](shared-review-scope-protocol.md), [shared-change-context.md](shared-change-context.md), and [functional-review.md](functional-review.md) before routing. [Packet preparation](packet-preparation.md) supplies these original contents and every Known-profile detection rule together; Read all parts completely, or use its direct-read fallback. Already loaded, unchanged instructions need not be read twice. The common context and functional method apply even without active profiles or specification documents.

### 2) Select the diff from filenames/metadata

Use `git status -sb` and diff statistics/filenames only. Honor an explicit user-selected scope/range; otherwise select unstaged changes, falling back to staged changes when none are unstaged. If neither exists, report no changes and request a range. Record the chosen selector and keep it for investigation. Do not silently combine staged and unstaged scopes.

A large diff (>500 lines) needs focused batching, not an early content dump.
This phase selects the Git diff only. Locating feature documents and determining
task scope belong to investigation after checklist loading. Finding a task file
in a status/listing result does not make its requirements part of preparation.

### 3) Detect profiles and route all checklists

Invoke [shared-profile-detection.md](shared-profile-detection.md) with the scoped filenames. Read each known profile's `DETECTION.md` (directly or as complete original contents in the bootstrap packet) and evaluate its authoritative signals; do not stop enumerating after an obvious extension match. Path matches alone do not activate a profile. Multiple profiles may apply. Resolve the plugin root from this skill's loaded location (parent of `skills/`) and construct absolute profile paths; do not forward unresolved root tokens into tools.

Batch the Known-profile reads together when supported, then reconcile expected paths with completed lookups. Record each rule's match/non-match or the shared procedure's explicit unavailable-file outcome; apply that procedure's ENOENT and root-resolution fallbacks. A skipped lookup leaves routing incomplete even when a file extension suggests an obvious profile. This prevents an assumed negative from hiding an additional applicable profile.

For every active profile, read its `profiles/<profile>/review-code/index.md`. Collect **Always load** entries. Evaluate filename/metadata **Load if:** predicates first. For declared content predicates in detection or conditional loading, inspect at most approximately 16 KiB per candidate file, solely to resolve the predicate; log predicate/path. Apply the detection protocol's YAML document rules where relevant. If a conditional cannot be decided within the bound, conservatively select its instruction. Do not defer any conditional until after full source investigation.

Collect `(profile, checklist, triggered_by)` records for all matching/conservatively selected entries, carrying detection provenance and noting conservative selections. Indexes are authoritative; never hardcode checklist names. No profile means an empty list, not omission of the common method.

### 4) Read every resolved checklist

Read each selected `profiles/<profile>/review-code/<checklist>` using the resolved absolute plugin root, or Read the complete selected-checklist packet from [packet preparation](packet-preparation.md). An index read is routing, not checklist loading: every selected link requires its returned original content, even for a tiny diff. Keep the source paths as a loading ledger and mark them loaded only when complete read results arrive. Do not batch investigation commands with these reads.

Before proceeding, emit a compact loading checkpoint naming the completed common-instruction reads, every known profile's detection-lookup outcome, and the loaded checklist paths (or explicitly no active profiles). Any selected path without returned content keeps the gate closed; surface unreadable instructions and stop, except for detection fallbacks explicitly defined by the shared procedure. This checkpoint records evidence already obtained, not a promise to load guidance later. It catches accidental index-to-diff shortcuts without creating a separate artifact or replacing the actual read events.

### 5) Investigate behavior and compatibility

This is the single entry point for subject-matter investigation. With methodology loaded:

- Locate and read available component README/contract documentation and relevant requirements/task documents first; build task scope with the shared protocol and establish explicit intent and preserved invariants. Label inference where no contract exists. Distinguish review base/candidate from any release baseline.
- Then read the full diff using the selector from scope and re-read every changed file at the reviewed revision, accounting for deletions. Do not rely on an earlier conversation's contents. Use index blobs for staged review and the selected candidate revision for a commit range; do not silently substitute unrelated worktree contents.
- Apply the common functional method: trace changed behavior through relevant dependencies and unchanged consumers, exercise concrete scenarios, and assess relevant delivery combinations. Obtain actual historical source when needed; label provenance and unavailable evidence using the shared context rules.
- Search `kk:review-findings` for relevant patterns and, for active programming-language profiles, `kk:lang-idioms`. With no language results, optionally index a canonical idioms source under that label. Skip language lookup for non-language profiles.

If investigation adds targets covered by new profiles or newly applicable conditionals, pause analysis of those targets and return to routing/loading before continuing. Subsequent focused re-reads, reproductions and verification substantiate findings within this investigation; they do not create another full-diff preflight. Keep claims within actual access and evidence.

### 6) Apply profile and general checklists

Apply every loaded `(profile, checklist, triggered_by)` record to the affected behavior and diff. Domain checklists supplement the common method. Tag findings with their profile/checklist origin and detection signal; use `Profile: generic · Checklist: —` and `Triggered by: —` for common reasoning. Keep severity-major output and merge duplicate issues across lenses.

General guidance that applies regardless of profile — apply these categories on every diff, whether or not a profile-specific checklist covered them:

- **SOLID / architecture:** SRP violations (overloaded modules with unrelated responsibilities), OCP (frequent edits to add behavior instead of extension points), LSP (subclasses that break expectations or require type checks), ISP (wide interfaces with unused methods), DIP (high-level logic tied to low-level implementations). When you propose a refactor, explain _why_ it improves cohesion/coupling and outline a minimal, safe split. If refactor is non-trivial, propose an incremental plan instead of a large rewrite.

END PACKET PART 1/6
