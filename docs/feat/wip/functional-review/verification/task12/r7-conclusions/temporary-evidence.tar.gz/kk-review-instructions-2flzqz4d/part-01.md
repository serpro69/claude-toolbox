Instruction packet profiles: part 1/1


BEGIN SOURCE /home/sergio/.codex/plugins/cache/fr-r7-bf873de6-20261013/kk/0.23.0/profiles/python/review-code/index.md
SHA256 f61a2b16b8a5ff1f4f6e03d1c19447f6626732a0dc702a997310872987fc0ba6
Resolve links relative to this original source path.

# Python — review checklists

Consumed by the `$kk:review-code` skill. When the `python` profile is active, every checklist in **Always load** is applied to the diff. There are no conditional entries for this profile.

## Always load

- [security-checklist.md](security-checklist.md) — Python-specific security smells: input validation, deserialization, subprocess/shell injection, crypto misuse, secret handling.
- [solid-checklist.md](solid-checklist.md) — SOLID design-principle smells expressed in Python: module cohesion, protocol segregation, dependency inversion, duck-typing boundaries.
- [code-quality-checklist.md](code-quality-checklist.md) — idiomatic Python quality signals: typing, mutability, context managers, exception hygiene, maintainability.
- [removal-plan.md](removal-plan.md) — staged-removal template for Python code being retired (modules, packages, public APIs).

END SOURCE

END PACKET PART 1/1
