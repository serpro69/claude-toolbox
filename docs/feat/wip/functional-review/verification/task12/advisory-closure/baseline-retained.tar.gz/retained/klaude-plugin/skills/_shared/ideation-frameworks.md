<!-- Adapted from addyosmani/agent-skills (MIT License, Copyright Addy Osmani)
     Source: https://github.com/addyosmani/agent-skills/blob/539a78574773fe7e46cf8bbf9c67bcc9db63c335/skills/idea-refine/frameworks.md
     Pinned at: 539a78574773fe7e46cf8bbf9c67bcc9db63c335 -->

# Ideation Frameworks Reference

These frameworks apply to software engineering features — APIs, infrastructure, developer tools, internal systems, library design. The goal is to unlock thinking about implementation approaches and architectural trade-offs, not to follow a checklist. Pick the lens that fits the idea; don't mechanically run every framework.

## SCAMPER

A structured way to transform an existing idea by applying seven different operations:

- **Substitute:** What component, technology, or process could you swap out? What if you replaced the synchronous RPC with an event-driven approach? The relational database with a document store? The monolith deployment with a service mesh?
- **Combine:** What if you merged this with another product, service, or idea? What two things that don't usually go together would create something new?
- **Adapt:** What else is like this? What ideas from other domains or systems could you borrow? What parallel exists in nature?
- **Modify (Magnify/Minimize):** What if you made it 10x bigger? 10x smaller? What if you exaggerated one feature? What if you stripped it to the absolute minimum?
- **Put to other uses:** Who else could use this? What other problems could it solve? What happens if you use it in a completely different context?
- **Eliminate:** What happens if you remove a feature entirely? What's the version with zero configuration? What would it look like with half the steps?
- **Reverse/Rearrange:** What if you did the steps in the opposite order? What if the user/client did the work instead of the system/server (or vice versa)? What if you reversed the dependency direction, or the value chain?

**Best for:** Improving or reimagining existing systems/products/features. Less useful for greenfield ideas.

## How Might We (HMW)

Reframe problems as opportunities using the "How Might We..." format:

- Start with an observation or pain point
- Reframe it as "How might we [desired outcome] for [specific user] without [key constraint]?"
- Generate multiple HMW framings of the same problem — different framings unlock different solutions

**Good HMW qualities:**
- Narrow enough to be actionable ("...help new users find relevant content in their first 5 minutes")
- Broad enough to allow creative solutions (not "...add a recommendation sidebar")
- Contains a tension or constraint that forces creativity

**Bad HMW qualities:**
- Too broad: "How might we make users happy?"
- Too narrow: "How might we add a button to the settings page?"
- Solution-embedded: "How might we build a chatbot for support?"

**Best for:** Reframing stuck thinking. When someone is anchored on a solution, pull them back to the problem.

## First Principles Thinking

Break the idea down to its fundamental truths, then rebuild from there:

1. **What do we know is true?** (not assumed, not conventional — actually true)
2. **What are we assuming?** List every assumption, even the ones that feel obvious
3. **Which assumptions can we challenge?** For each, ask: "Is this actually a law of physics, or just how it's been done?"
4. **Rebuild from the truths.** If you only had the fundamental truths, what would you build?

**Best for:** Breaking out of incremental thinking. When every idea feels like a small improvement on the status quo.

## Jobs to Be Done (JTBD)

Focus on what the user is trying to accomplish, not what they say they want:

- **Functional job:** What task are they trying to complete?
- **Emotional job:** How do they want to feel?
- **Social job:** How do they want to be perceived?

Format: "When I [situation], I want to [motivation], so I can [expected outcome]."

**Key insight:** Users don't adopt tools — they hire them to do a job. The competing solution isn't always in the same category. (A CLI tool competes with a shell script alias, not just other CLI tools.)

**Best for:** Understanding the real problem. When you're not sure if you're solving the right thing.

## Constraint Mapping

Deliberately impose constraints to force creative solutions:

- **Time constraint:** "What if you only had 1 day to build this?"
- **Feature constraint:** "What if it could only have one feature?"
- **Tech constraint:** "What if you couldn't use [the obvious technology]?"
- **Cost constraint:** "What if it had to be free forever?"
- **Audience constraint:** "What if your user had never used a computer before?"
- **Scale constraint:** "What if it needed to work for 1 billion users? What about just 10?"

**Best for:** Cutting through complexity. When the idea is growing too large or too vague.

## Pre-mortem

Imagine the idea has already failed. Work backwards:

1. It's 12 months from now. The project shipped and flopped. What went wrong?
2. List every plausible reason for failure — technical, adoption, integration, operational
3. For each failure mode: Is this preventable? Is this a signal the idea needs to change?
4. Which failure modes are you willing to accept? Which ones would kill the project?

**Best for:** Phase 2 evaluation. Stress-testing ideas that feel good but haven't been pressure-tested.

## Analogous Inspiration

Look at how other domains solved similar problems:

- What industry or system has already solved a version of this problem?
- What would this look like if someone else built it?
- What natural system or distributed system works this way?
- What historical precedent exists?

The key is finding *structural* similarities, not surface-level ones. "Git for config files" is surface-level. "A content-addressable store with branching semantics that solves the concurrent-edit problem" is structural.

**Best for:** Phase 1 expansion. Generating variations that feel genuinely different from the obvious approach.
