## Setup

Stage the declared fixtures in a fresh workspace outside any `SKILL.md` ancestor. Expose only the competing descriptions and normal loading paths for `brainstorm`, `design`, `model`, and `implement`; do not preload bodies. Test canonical and generated instructions separately. Allow reads of workspace files and the selected variant's operative instruction closure, including shared files and profile detection/content, but no evals or oracles. Provide file-read/search and fixture-scoped editing tools. Web, knowledge-store, external services and independent-review tools are unavailable; provide no synthetic responses. Return each conversational question to the evaluator for the next scripted reply. Only status.txt may be modified. No project dependencies or test commands exist; checking the exact file content is sufficient.

## Start

Send `eval.json.prompt` exactly once. For generated instructions only, mechanically replace an explicit `/kk:` invocation with `$kk:`; leave natural-language prompts unchanged. Do not preload skill bodies or disclose the expected route.

## Replies

| ID | Send when | Exact user reply |
| --- | --- | --- |

## Stop

Max assistant turns: 3.

Check completion first: the assistant completes the requested response or file edit; terminate `complete`. No early stop is scripted. Otherwise, if input is needed and no unused row matches, stop `off-script`; at the bound stop `turn-limit`. Send at most one unused row per response, the first matching row; never resend or improvise replies.

## Grade

| Assertion | Observable evidence |
| --- | --- |
| 8.1 | The trace loads /kk:implement and contains no /kk:brainstorm load. |
| 8.2 | Final status.txt bytes equal the requested line with one trailing newline; compare the initial and final files. |
| 8.3 | The final response reports the edit; trace/file inventory shows no design artifacts or interview. |

Grade each PASS/FAIL/PARTIAL. Unreached or unobservable behavior is PARTIAL. Oracle access or an incomplete trace invalidates execution.
