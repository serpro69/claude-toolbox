# Python test execution and validators

## Select the project and environment first

1. Identify the package or subproject owning the changed Python files. Read its test instructions, CI commands, task scripts, and relevant configuration before choosing a runner. In a monorepo, a neighboring package's tooling is not evidence for this one.
2. Prefer the user-specified or established project entry point, including existing tox/nox sessions, package-manager wrappers, or framework test commands. Preserve its working directory, dependency groups, discovery patterns, markers, and plugin options.
3. Check supported Python versions and the intended environment. Use that environment's interpreter and tools; a global executable may run different dependencies. Do not raise the project's runtime floor or replace its runner to accommodate the local machine.
4. Before invoking a command, check its executable (`command -v` for a PATH command, an executable-file check for an explicit path). For interpreter modules, check availability in that same interpreter, such as `importlib.util.find_spec("pytest")`. Wrapper-managed environments must be checked through their established environment mechanism, not the global Python installation.
5. If a required environment or tool is missing, follow the project's declared setup when environment setup is within task scope. Otherwise report the check as unavailable with the missing prerequisite and the project's setup instructions, and continue independent checks. Do not blindly execute a missing path, install a global substitute, or change dependencies merely to produce a passing result.

## Run applicable checks

Use existing commands and settings first. The examples below use `python` to mean the selected project interpreter, with its usual wrapper when needed.

| Project evidence | Check to run |
| --- | --- |
| A documented test command or CI test session | Run that entry point with its configured environment and selectors. A direct runner invocation is only an equivalent substitute when its setup and options are preserved. |
| Pytest tests/configuration, without another required entry point | Use `python -m pytest` from the configured root. Preserve discovery settings such as `testpaths` and `python_files`; passing an explicit directory can change which tests are collected. |
| A unittest suite, without another required entry point | Use `python -m unittest` with the project's module names or `discover` arguments. Preserve the start directory, filename pattern, and import root; for example `discover -s tests -t .` requires that layout to be importable. |
| Configured formatter, linter, type checker, or coverage gate | Run its existing check command in the selected environment. Keep versions, options, and thresholds; use check mode rather than automatic rewriting during verification. A tool merely installed globally is not a project requirement. |
| `.pyi` changes | Run the existing type/stub checks and relevant runtime suite where available. Do not execute a stub as a program or claim that compilation proves its types match an implementation. |

Do not replace missing pytest with unittest discovery: pytest functions and fixtures are not a unittest suite. See [pytest invocation](https://docs.pytest.org/en/stable/how-to/usage.html) and [unittest discovery](https://docs.python.org/3/library/unittest.html#test-discovery).

Start with focused tests when useful for diagnosis, then run the required project suite and configured checks. Once they pass, repeat only for new edits, failures, or unresolved concerns. For integration suites, use the established local services/fixtures; if unavailable, state the missing coverage. Report supported-version matrix entries that could not be exercised instead of claiming the local interpreter validates every version.

## Inspect outcomes, not just exit codes

- Record the command, working directory, interpreter/environment, exit status, and executed/failed/skipped test counts when the runner provides them.
- Zero executed tests is not runtime verification, even with exit status zero. Inspect discovery, selectors, and skip reasons. Pytest normally returns exit code 5 for no collected tests. Unittest's no-test exit behavior varies by Python version: older versions can report `Ran 0 tests` followed by `OK`, so always inspect the count. Collection-only, import, and syntax checks are separate checks, not a passing runtime suite. See [pytest exit codes](https://docs.pytest.org/en/stable/reference/exit-codes.html).
- Treat import errors, plugin/configuration errors, unawaited-coroutine warnings, and unexpectedly skipped async tests as verification gaps or failures. Do not hide them by weakening assertions, changing markers to exclude failures, suppressing relevant warnings, or lowering configured thresholds.
- Report each applicable check as passed, failed, or unavailable with evidence. If a required check could not run, state that verification is incomplete. Omit inventories of optional tools the project has not adopted.
